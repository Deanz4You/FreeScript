const fs = require('fs')

/* #pengembang rissxd
youtube : https://youtube.com/@rissmdbotz

/* #recode xyzdev
HAPUS WM INI DOSA BESAR LU NJIR 
TAMBAHIN NAMALU AJA KALO LU NGEMBANGIN
NIH SC

[ ! ] JANGAN DIJUAL ANJENG LU NGAK NGEHARGAIN GW NAMANYA
*/

// Setting Utama
// GANTI NOMOR OWNER JUGA DI START/LIB/DATABASE/OWNER.JSON
global.owner = "6283852293849" //owner number
global.namabot = "XYZ AI"
global.ownername = "XYZDEV"
// Watermark
global.footer = "XYRO DST OFFCIAL" //footer section
global.packname = "Sticker By"
global.author = "XYZ AI"

//CPANEL CIK
global.domain = 'https://hariskun.web-store.biz.id' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_ORBtvRGmSZgTYHlHgZwxmQ57xHwOgAXzMarq2PiNMZw'// Isi Apikey Plta Lu
global.capikey = 'ptlc_ig8f5Ftv9t8980RDc5Q8irxW53pk2utJ7gi5ZNaFIqe' //isi pltclu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.tekspanel = `NOTE :
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================`

// Saluran Whatsapp
global.idsaluran = "120363357315328608@newsletter"
global.namasaluran = "XYZDEV OFFC"

// Image
global.thumbnail = 'https://e.top4top.io/p_3261fpqw10.jpeg'

//database
global.urldb = ''; // kosongin aja tapi kalo mau pake database mongo db isi url mongo
global.themeemoji = '🔥'
global.mess = {
ingroup: "It's not funny, this feature is only for groups💢",
admin: "not funny, only group admins use this feature💢",
botadmin: "bot bukan admin🤘😁✌️",
owner: "Wow! You're not my owner🗣️",
premium: "you are not a premium user",
seller: "You don't have access as a seller yet",
wait: "please just wait ngab",
daftar: "kamu belum terdaftar\nsilahkan ketik .daftar"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
