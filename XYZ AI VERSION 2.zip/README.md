## First Project
Hello friends, this is my first project, please understand if you find any errors, friends✨, don't forget to give stars and follow 🐈‍⬛
## Thank you to those who have helped me ✨

- [`kiuur`](https://github.com/kiuur) KyuuRzy ( crator )
- [`Hyuu`](https://github.com/hyuux) Hyuu ( my friend )
- [`KiiCode`](https://github.com/mdzakidev) KiiCode/Zaki ( my friend )
- [`xyzencode`](https://github.com/xyzencode) Adriannn ( sengpuh 🥶 )
- [`RullZy`](https://github.com/rlzyy) RullZy ( my friend )
- [`RissXD`](https://chat.whatsapp.com/HCdOZsRFUry20aE5157uhy) RissXD ( Pengembang)
- [`XyzDev`](https://github.com/XYZDEV99) XYZDEV ( Developer )

without them this script is nothing, thank you to them 💫

```javascript
console.log("anti aldog 🐕")
```
## License

This project is licensed under the MIT License - see the LICENSE file for details.
