const settings = {
  token: 'TokenBotLu', // Token Bot
  adminId: 'IDTeleLu',
  urladmin: 'https://t.me/DhannSU',
  pp: 'https://files.catbox.moe/zragi1.jpg',
    //SERVER 1
  domain: 'https', // Isi dengan domain yang digunakan
  plta: 'ptla', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc', // Isi dengan nilai pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;