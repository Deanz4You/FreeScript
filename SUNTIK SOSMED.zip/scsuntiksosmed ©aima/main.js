//SCRIPT BY AimaGpx JANGAN JUAL SCRIPT INI KARNA INI GRATIS DARI TikTok @AimaGpx//
//JIKA INGIN MEMBELI YANG NO ENC SILAHKAN HUBUNGI NOMOR INI : 6288803536269
require("./seting");
const {
  WA_DEFAULT_EPHEMERAL,
  getAggregateVotesInPollMessage,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  getContentType
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const chalk = require("chalk");
const crypto = require("crypto");
const axios = require("axios");
const moment = require("moment-timezone");
const fetch = require("node-fetch");
const util = require("util");
const cheerio = require("cheerio");
const {
  exec,
  spawn,
  execSync
} = require("child_process");
const {
  sizeFormatter
} = require("human-readable");
const format = sizeFormatter();
const {
  color,
  bgcolor,
  mycolor
} = require("./database/color");
const {
  apikey
} = require("./apikey.json");
const {
  buglins
} = require("./database/buglins");
const {
  smsg,
  isUrl,
  sleep,
  runtime,
  fetchJson,
  getBuffer,
  jsonformat
} = require("./database/functions");
const {
  Primary
} = require("./seting");
moment.tz.setDefault("Asia/Jakarta").locale("id");
module.exports = zann = async (_0x2f598b, _0x56ef70, _0x17c35e, _0x348153) => {
  try {
    const _0x455042 = _0x56ef70.mtype === "conversation" ? _0x56ef70.message.conversation : _0x56ef70.mtype == "imageMessage" ? _0x56ef70.message.imageMessage.caption : _0x56ef70.mtype == "videoMessage" ? _0x56ef70.message.videoMessage.caption : _0x56ef70.mtype == "extendedTextMessage" ? _0x56ef70.message.extendedTextMessage.text : _0x56ef70.mtype == "buttonsResponseMessage" ? _0x56ef70.message.buttonsResponseMessage.selectedButtonId : _0x56ef70.mtype == "listResponseMessage" ? _0x56ef70.message.listResponseMessage.singleSelectReply.selectedRowId : _0x56ef70.mtype == "templateButtonReplyMessage" ? _0x56ef70.message.templateButtonReplyMessage.selectedId : _0x56ef70.mtype === "messageContextInfo" ? _0x56ef70.message.buttonsResponseMessage?.selectedButtonId || _0x56ef70.message.listResponseMessage?.singleSelectReply.selectedRowId || _0x56ef70.text : "";
    const _0x25bc4c = typeof _0x56ef70.text == "string" ? _0x56ef70.text : "";
    const _0x2d41a8 = /^[°#*+,.?=''():√%!¢£¥€π¤ΠΦ_&`™©®Δ^βα¦|/\\©^]/.test(_0x455042) ? _0x455042.match(/^[°#*+,.?=''():√%¢£¥€π¤ΠΦ_&!™©®Δ^βα¦|/\\©^]/gi) : ".";
    const _0x3533d1 = _0x56ef70.mtype === "conversation" && _0x56ef70.message.conversation ? _0x56ef70.message.conversation : _0x56ef70.mtype == "imageMessage" && _0x56ef70.message.imageMessage.caption ? _0x56ef70.message.imageMessage.caption : _0x56ef70.mtype == "documentMessage" && _0x56ef70.message.documentMessage.caption ? _0x56ef70.message.documentMessage.caption : _0x56ef70.mtype == "videoMessage" && _0x56ef70.message.videoMessage.caption ? _0x56ef70.message.videoMessage.caption : _0x56ef70.mtype == "extendedTextMessage" && _0x56ef70.message.extendedTextMessage.text ? _0x56ef70.message.extendedTextMessage.text : _0x56ef70.mtype == "buttonsResponseMessage" && _0x56ef70.message.buttonsResponseMessage.selectedButtonId ? _0x56ef70.message.buttonsResponseMessage.selectedButtonId : _0x56ef70.mtype == "templateButtonReplyMessage" && _0x56ef70.message.templateButtonReplyMessage.selectedId ? _0x56ef70.message.templateButtonReplyMessage.selectedId : _0x56ef70.mtype == "listResponseMessage" ? _0x56ef70.message.listResponseMessage.singleSelectReply.selectedRowId : _0x56ef70.mtype == "messageContextInfo" ? _0x56ef70.message.listResponseMessage.singleSelectReply.selectedRowId : "";
    const _0x405002 = JSON.stringify(_0x56ef70.message);
    const {
      type: _0x5aedb7,
      quotedMsg: _0x3a5509,
      mentioned: _0x2c428f,
      now: _0x111088,
      fromMe: _0x3c1698
    } = _0x56ef70;
    const _0x1b34b4 = _0x455042.startsWith(_0x2d41a8);
    const _0x1c3709 = _0x56ef70.key.remoteJid;
    const _0x42ccef = _0x455042.replace(_0x2d41a8, "").trim().split(/ +/).shift().toLowerCase();
    const _0x3608a4 = _0x455042.trim().split(/ +/).slice(1);
    const _0x3d7b80 = _0x56ef70.pushName || "No Name";
    const _0x3e3ae6 = await _0x2f598b.decodeJid(_0x2f598b.user.id);
    const _0x2c380a = [_0x3e3ae6, ...global.owner].map(_0x3ef414 => _0x3ef414.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(_0x56ef70.sender);
    const _0x44d343 = _0x56ef70.sender == _0x3e3ae6 ? true : false;
    const _0x2438f0 = q = _0x3608a4.join(" ");
    const _0x43fba9 = _0x56ef70.quoted ? _0x56ef70.quoted : _0x56ef70;
    const _0x231c50 = (_0x43fba9.msg || _0x43fba9).mimetype || "";
    const _0x515566 = /image|video|sticker|audio/.test(_0x231c50);
    const {
      chats: _0x498eec
    } = _0x56ef70;
    const _0x25d45b = {
      react: {
        text: "🌸",
        key: _0x56ef70.key
      }
    };
    const _0x3de9ac = {
      react: {
        text: "🌸",
        key: _0x56ef70.key
      }
    };
    const _0x27d53e = moment.tz("Asia/Jakarta").format("DD/MM/YY");
    const _0x3aa39a = moment.tz("asia/jakarta").format("HH:mm:ss");
    const _0x2fff97 = _0x43fba9.msg || _0x43fba9;
    const _0x12bdbb = _0x56ef70.chat.endsWith("@g.us");
    const _0x31a1c6 = _0x56ef70.isGroup ? await _0x2f598b.groupMetadata(_0x56ef70.chat).catch(_0x23858b => {}) : "";
    const _0x42e84c = _0x56ef70.isGroup ? _0x31a1c6.subject : "";
    const _0x34646b = _0x56ef70.isGroup ? await _0x31a1c6.participants : "";
    const _0x3a33a6 = _0x56ef70.isGroup ? await _0x34646b.filter(_0x3d3489 => _0x3d3489.admin !== null).map(_0xac492b => _0xac492b.id) : "";
    const _0x23b7e1 = _0x56ef70.isGroup ? _0x31a1c6.owner : "";
    const _0x15bcdf = _0x56ef70.isGroup ? _0x31a1c6.participants : "";
    const _0x96c95a = _0x56ef70.isGroup ? _0x3a33a6.includes(_0x3e3ae6) : false;
    const _0x422910 = _0x56ef70.key.fromMe ? _0x2f598b.user.id.split(":")[0] + "@s.whatsapp.net" || _0x2f598b.user.id : _0x56ef70.key.participant || _0x56ef70.key.remoteJid;
    const _0x545bd2 = _0x422910.split("@")[0];
    const _0x52e102 = _0x56ef70.isGroup ? _0x3a33a6.includes(_0x56ef70.sender) : false;
    const _0x3986bd = _0x56ef70.isGroup ? _0x3a33a6.includes(_0x56ef70.sender) : false;
    const _0x20083 = _0x5aedb7 == "extendedTextMessage";
    if (!_0x2f598b.public) {
      if (!_0x56ef70.key.fromMe) {
        return;
      }
    }
    if (_0x1b34b4 && _0x56ef70.isGroup) {
      console.log(chalk.bold.rgb(255, 178, 102)("[1;31m~[1;37m> [[1;32mCMD[1;37m]"), chalk.bold.rgb(153, 255, 153)(_0x42ccef), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(_0x3d7b80), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Group Chat"), chalk.bold("[" + _0x3608a4.length + "]"));
    }
    if (_0x1b34b4 && !_0x56ef70.isGroup) {
      console.log(chalk.bold.rgb(255, 178, 102)("[1;31m~[1;37m> [[1;32mCMD[1;37m]"), chalk.bold.rgb(153, 255, 153)(_0x42ccef), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(_0x3d7b80), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Private Chat"), chalk.bold("[" + _0x3608a4.length + "]"));
    }
    try {
      ppuser = await _0x2f598b.profilePictureUrl(_0x56ef70.sender, "image");
    } catch (_0x1fe6cb) {
      ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }
    ppnyauser = await getBuffer(ppuser);
    function _0x1c9c02(_0x5935e4, _0x433eda = [], _0x543188) {
      if (_0x543188 == null || _0x543188 == undefined || _0x543188 == false) {
        let _0x1a3e00 = _0x2f598b.sendMessage(_0x1c3709, {
          text: _0x5935e4,
          mentions: _0x433eda
        }, {
          quoted: _0x56ef70
        });
        return _0x1a3e00;
      } else {
        let _0x4a0e82 = _0x2f598b.sendMessage(_0x1c3709, {
          text: _0x5935e4,
          mentions: _0x433eda
        }, {
          quoted: _0x56ef70
        });
        return _0x4a0e82;
      }
    }
    const _0x6ca4be = _0x5aedb7 == "extendedTextMessage" && _0x56ef70.message.extendedTextMessage.contextInfo != null ? _0x56ef70.message.extendedTextMessage.contextInfo.mentionedJid : [];
    const _0x508530 = _0x5aedb7 == "extendedTextMessage" && _0x56ef70.message.extendedTextMessage.contextInfo != null ? _0x56ef70.message.extendedTextMessage.contextInfo.participant || "" : "";
    const _0x5edd0a = typeof _0x6ca4be == "string" ? [_0x6ca4be] : _0x6ca4be;
    if (_0x5edd0a != undefined) {
      _0x5edd0a.push(_0x508530);
    } else {
      [];
    }
    const _0x3e3835 = _0x5edd0a != undefined ? _0x5edd0a.filter(_0x40b9ec => _0x40b9ec) : [];
    const _0xc7f132 = _0x260a28 => {
      return crypto.randomBytes(_0x260a28).toString("hex").slice(_0x422910, _0x260a28);
    };
    const _0x2b8cf4 = _0x498d29 => {
      return _0x498d29[Math.floor(Math.random() * _0x498d29.length)];
    };
    const _0x19cc4d = _0x130ebf => {
      return "" + Math.floor(Math.random() * 10000) + _0x130ebf;
    };
    const _0x50a5a0 = _0x1a7dde => {
      _0x2f598b.sendMessage(_0x56ef70.chat, {
        text: _0x1a7dde
      }, {
        quoted: _0x56ef70
      });
    };
    global.mess = {
      wait: "Mencari...🔎",
      succes: "Sukses Om",
      admin: "Khusus Admin Om",
      botAdmin: "Jadikan Bot Admin Grup",
      owner: "Sepertinya Bukan Owner",
      group: "Untuk Grup Kak",
      private: "Privat Kak Bukan Di Grup",
      bot: "Untuk Bot",
      error: "Eror!! Hubungi Owner Kenapa Bisa Eror",
      Akses: "Anda Tidak Terdaftar Akses Dalam Database",
      develop: "Fitur Khusus Develop aimagpx"
    };
    async function _0x4daff3(_0x34d637 = "", _0x3d6c37 = {}) {
      const _0x5280dd = await fetch(_0x34d637, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(_0x3d6c37)
      });
      return _0x5280dd.json();
    }
    switch (_0x42ccef) {
      case "menu":
        {
          let _0xd2d70e = "╔═══「ᴍᴇɴᴜ ʙᴏᴛ 」════❑\n╠➣ .Welcome : " + _0x3d7b80 + "\n╠➣ .Name Bot : " + global.author + "\n╠➣ .Numbers : " + global.owner + "\n╠➣ .Running : Panel Only\n╠➣ .Version : Beta\n╠➣ .Info : Bot Whatsapp New\n╠➣ .buysc : ketik cmd disamping\n╚══════════════❑\n║\n╔═══「ᴍᴇɴᴜ ʙᴏᴛ 」════☕︎\n╠➣ .addprem 62𝚡𝚡𝚡𝚡\n╠➣ .delprem 62𝚡𝚡𝚡𝚡\n╠➣ .listprem \n╠➣ .kick 62𝚡𝚡𝚡𝚡\n╠➣ .join \n╠➣ .grup 𝚘𝚗/𝚘𝚏\n╠➣ .tagall\n╠➣ .sticker\n╚══════════════❑\n║\n╔══「sᴜɴᴛɪᴋ sᴏsᴍᴇᴅ」═══❑\n╠➣ .profil \n╠➣ .listproduk \n╠➣ .cekorder ⧼ ID ⧽\n╠➣ .service ⧼ 𝙻𝙸𝚂𝚃 𝙿𝚁𝙾𝙳𝚄𝙺 ⧽\n╠➣ .𝚘𝚛𝚍𝚎𝚛 ⧼ 𝙸𝙳|𝙹𝚄𝙼𝙻𝙰𝙷|𝙻𝙸𝙽𝙺 ⧽\n╠➣ .status ⧼ 𝙸𝙳 𝙿𝙴𝚂𝙰𝙽 ⧽\n╠➣ .suntik ⧼ 𝙸𝙳,𝚓𝚞𝚖𝚕𝚊𝚑,𝚕𝚒𝚗𝚔 ⧽\n╠➣ .ttview ⧼ 𝚕𝚒𝚗𝚔 ⧽\n╚═════════════❑\n║\n╔══「ᴍᴇɴᴜ ʀᴀɴᴅᴏᴍ」═══❑\n╠➣ .pushkontak \n╠➣ .asupan1\n╠➣ .asupan2\n╠➣ .asupan3\n╠➣ .asupan4\n╠➣ .asupan5\n╠➣ .hd\n╠➣ .waifu \n╠➣ .neko \n╠➣ .random\n╚════════════❑\n║\n╔══「ᴅᴏᴡɴʟᴏᴀᴅᴇʀ」═══❑\n╠➣ .ig ⧼ 𝚕𝚒𝚗𝚔 ⧽\n╠➣ .tiktok\n╠➣ .slidetiktok\n╠➣ .ytmp3\n╠➣ .ytmp4\n╚═════════════❑\n║\n═══「ɪɴғᴏʀᴍᴀsɪ」════❑\n𝘏𝘦𝘭𝘭𝘰 𝘢𝘭𝘭𝘭, 𝘣𝘰𝘵 𝘸𝘩𝘢𝘵𝘴𝘢𝘱𝘱 𝘪𝘯𝘪 \n𝘥𝘪𝘣𝘶𝘢𝘵 𝘰𝘭𝘦𝘩 𝘻𝘢𝘯𝘯𝘮𝘰𝘥𝘴, 𝘬𝘮𝘪 \n𝘮𝘦𝘯𝘺𝘦𝘥𝘪𝘢𝘬𝘢𝘯 𝘣𝘦𝘣𝘦𝘳𝘢𝘱𝘢 𝘧𝘪𝘵𝘶𝘳 \n𝘮𝘦𝘯𝘢𝘳𝘪𝘬 𝘥𝘪𝘩𝘰𝘵𝘦𝘭 𝘸𝘩𝘢𝘵𝘴𝘢𝘱𝘱 𝘪𝘯𝘪 𝘭𝘰𝘩. \n𝗦𝘂𝗽𝗽𝗼𝗿𝘁 𝗦𝗼𝘀𝗺𝗲𝗱 𝗞𝗮𝗺𝗶.\n𝘠𝘰𝘶𝘵𝘶𝘣𝘦 : @AimaGpx\n𝘛𝘦𝘭𝘦𝘨𝘳𝘢𝘮 : t.me/AimaGpx\n𝘵𝘪𝘬𝘵𝘰𝘬 : @tangerangcyber\n𝘪𝘨 : @AimaGpx\n══════════════❑";
          _0x50a5a0(_0xd2d70e);
        }
        break;
      case "self":
        {
          if (!_0x2c380a) {
            return _0x50a5a0(mess.develop);
          }
          _0x2f598b.public = false;
          _0x50a5a0("Succes Change To Self");
        }
        break;
      case "public":
        {
          if (!_0x44d343) {
            throw _0x50a5a0("only bot");
          }
          _0x2f598b.public = true;
          _0x50a5a0("Succes Change To Public");
        }
        break;
      case "join":
        {
          if (!isCreator) {
            return _0x50a5a0("*Khusus Premium*");
          }
          if (!_0x2438f0) {
            throw "Masukkan Link Group!";
          }
          if (!isUrl(_0x3608a4[0]) && !_0x3608a4[0].includes("whatsapp.com")) {
            throw "Link Invalid!";
          }
          let _0x2dfaac = _0x3608a4[0].split("https://chat.whatsapp.com/")[1];
          await _0x2f598b.groupAcceptInvite(_0x2dfaac).then(_0x53674e => _0x50a5a0("Sukses Join masbro👌")).catch(_0x8c962d => _0x50a5a0(jsonformat(_0x8c962d)));
        }
        break;
      case "kick":
        {
          if (!_0x12bdbb) {
            return _0x50a5a0(mess.group);
          }
          if (!_0x96c95a) {
            return _0x50a5a0(mess.botAdmin);
          }
          if (!_0x52e102) {
            return _0x50a5a0(mess.admin);
          }
          let _0x3a3190 = _0x56ef70.mentionedJid[0] ? _0x56ef70.mentionedJid[0] : _0x56ef70.quoted ? _0x56ef70.quoted.sender : _0x2438f0.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await _0x2f598b.groupParticipantsUpdate(_0x1c3709, [_0x3a3190], "remove").then(_0x5c460f => _0x50a5a0(jsonformat(_0x5c460f))).catch(_0x2fc965 => _0x50a5a0(jsonformat(_0x2fc965)));
        }
        break;
      case "tagall":
        {
          if (!_0x12bdbb) {
            return _0x50a5a0(mess.group);
          }
          if (!_0x52e102) {
            return _0x50a5a0(mess.admin);
          }
          if (!_0x96c95a) {
            return _0x50a5a0(mess.botAdmin);
          }
          let _0x436250 = "*👏 Tag All By AimaGpx*\n\n🗞️ *Pesan : " + (q ? q : "kosong") + "*\n\n";
          for (let _0x49017f of _0x34646b) {
            _0x436250 += "• @" + _0x49017f.id.split("@")[0] + "\n";
          }
          _0x2f598b.sendMessage(_0x56ef70.chat, {
            text: _0x436250,
            mentions: _0x34646b.map(_0x34f664 => _0x34f664.id)
          }, {
            quoted: _0x56ef70
          });
        }
        break;
      case "group":
      case "grup":
        if (!_0x12bdbb) {
          return _0x50a5a0(mess.group);
        }
        if (!_0x52e102) {
          return _0x50a5a0(mess.admin);
        }
        if (!_0x96c95a) {
          return _0x50a5a0(mess.botAdmin);
        }
        if (_0x3608a4[0] == "off") {
          _0x2f598b.groupSettingUpdate(_0x1c3709, "announcement").then(_0x315be2 => _0x50a5a0(jsonformat(_0x315be2))).catch(_0x4b03c4 => _0x50a5a0(jsonformat(_0x4b03c4)));
        } else if (_0x3608a4[0] == "on") {
          _0x2f598b.groupSettingUpdate(_0x1c3709, "not_announcement").then(_0x2cae16 => _0x50a5a0(jsonformat(_0x2cae16))).catch(_0x2b0ee2 => _0x50a5a0(jsonformat(_0x2b0ee2)));
        } else {
          _0x50a5a0("Kirim perintah #" + _0x42ccef + " _options_\nOptions : on & off\nContoh : " + (_0x2d41a8 + _0x42ccef) + " on");
        }
        break;
      case "profil":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          const _0x10c9c2 = await new ZannBot(api_id, api_key).cekProfile();
          _0x50a5a0("Profile Berhasil Ditemukan\n\nFull Name: " + util.format(_0x10c9c2.data.full_name) + "\nUsername: " + util.format(_0x10c9c2.data.username) + "\nSaldo: Rp " + util.format(_0x10c9c2.data.balance));
        }
        break;
      case "listproduk":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          if (!_0x3608a4[0]) {
            return _0x50a5a0("mau dikirim lewat apa ka\n1. document\n2. chat\n\nContoh: " + _0x42ccef + " 1");
          }
          await new ZannBot(api_id, api_key).cekServices("SMM").then(_0x21349e => {
            const _0x4923ff = _0x21349e.data.map((_0x412c07, _0x4c57b1) => {
              const _0x29cd70 = ["ID: " + _0x412c07.id + "\nProduct Name: " + _0x412c07.name + "\nDeskripsi: " + _0x412c07.description + "\nHarga: Rp " + _0x412c07.price + "\nCategory: " + _0x412c07.category + "\nMin Order: " + _0x412c07.min + "\nMax Order: " + _0x412c07.max].join("\n\n");
              return _0x29cd70;
            }).join("\n\n");
            if (_0x3608a4[0] == "2") {
              _0x50a5a0(_0x4923ff);
            }
            if (_0x3608a4[0] == "1") {
              _0x2f598b.sendMessage(_0x1c3709, {
                document: Buffer.from(_0x4923ff, "utf8"),
                fileName: "list-produk.txt",
                caption: "List Ada Di Dalem File Ini",
                mimetype: "text/plain"
              }, {
                quoted: _0x56ef70
              });
            } else {
              _0x50a5a0("perintah tidak ditemukan\nmasukkan perintah berikut:\n1. document\n2. chat\n\nContoh: " + _0x42ccef + " 1");
            }
          });
        }
        break;
      case "suntik":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          if (!q) {
            return _0x50a5a0("Silahkan Isi Format Berikut\n\n" + _0x42ccef + " ID Layanan,Jumlah Pesanan,Link Tujuan");
          }
          const _0x447e5e = q.split(",")[0];
          const _0x547e6a = q.split(",")[1];
          const _0x4b9bf6 = q.split(",")[2];
          let _0x1aebd4 = "Format Salah!!\nsilahkan isi sesuai format\n\n" + _0x42ccef + " ID Layanan,Jumlah Pesanan,Link Tujuan";
          if (!_0x447e5e && !_0x547e6a && !_0x4b9bf6) {
            return _0x50a5a0(_0x1aebd4);
          }
          try {
            await new ZannBot(api_id, api_key).order(_0x447e5e, _0x4b9bf6, _0x547e6a).then(_0x54ba9a => {
              const _0x4216b5 = _0x54ba9a.data;
              _0x50a5a0(util.format(_0x4216b5));
              console.log(_0x54ba9a);
            });
          } catch (_0x1e6db1) {
            _0x50a5a0(util.format(_0x1e6db1.response.data));
          }
        }
        break;
      case "cekorder":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          if (!q) {
            return _0x50a5a0("Example: " + _0x42ccef + " IdTransaksi");
          }
          try {
            await new ZannBot(api_id, api_key).cekStatus(q).then(_0x5018c1 => {
              const _0x319f20 = _0x5018c1.data;
              _0x50a5a0(util.format(_0x319f20));
            });
          } catch (_0x571b0f) {
            _0x50a5a0(util.format(_0x571b0f.response.data));
          }
        }
        break;
      case "ttview":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          if (!q) {
            return _0x50a5a0("Example: ttview https://vt.tiktok.com/ZSNCVsBC1/");
          }
          const _0x18c851 = "3367";
          const _0x450dee = "4899";
          const _0x2dfac9 = q;
          try {
            await new ZannBot(api_id, api_key).order(_0x18c851, _0x2dfac9, _0x450dee).then(_0x2313dc => {
              const _0x377e52 = _0x2313dc.data;
              _0x50a5a0(util.format(_0x377e52));
            });
          } catch (_0x21d357) {
            console.log(_0x21d357);
          }
        }
        break;
      case "service":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          if (!_0x3608a4[0]) {
            return _0x50a5a0("mau dikirim lewat apa ka\n1. document\n2. chat\n\nContoh: " + _0x42ccef + " 1");
          }
          _0x4daff3(keyUrl, {
            method: "POST",
            key: keyApi,
            action: "services"
          }).then(_0x9f526f => {
            let _0x41c637 = JSON.stringify(_0x9f526f);
            fs.writeFileSync("./database/database.json", _0x41c637);
          });
          await sleep(2000);
          let _0x3fd1c5 = JSON.parse(fs.readFileSync("./database/database.json"));
          let _0x5b4bb0 = "*「 SERVICE SOSMED 」*\n\n";
          _0x3fd1c5.forEach(function (_0x281d7d) {
            _0x5b4bb0 += "Service: " + _0x281d7d.service + "\nName: " + _0x281d7d.name + "\nMinimal: " + _0x281d7d.min + "\nMaximal: " + _0x281d7d.max + "\nRate: " + _0x281d7d.rate + "\nRefill: " + _0x281d7d.refill + "\nUnit: " + _0x281d7d.unit + "\nTarget: " + _0x281d7d.target_info + "\n\n\n";
          });
          if (_0x3608a4[0] == "2") {
            _0x50a5a0(_0x5b4bb0);
          }
          if (_0x3608a4[0] == "1") {
            _0x2f598b.sendMessage(_0x1c3709, {
              document: Buffer.from(_0x5b4bb0, "utf8"),
              fileName: "service.txt",
              caption: "List Ada Di Dalem File Ini",
              mimetype: "text/plain"
            }, {
              quoted: _0x56ef70
            });
          } else {
            _0x50a5a0("perintah tidak ditemukan\nmasukkan perintah berikut:\n1. document\n2. chat\n\nContoh: " + _0x42ccef + " 1");
          }
        }
        break;
      case "order":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          let _0x2943e5 = q.split("|")[0];
          let _0x2c981c = q.split("|")[1];
          let _0x11f752 = q.split("|")[2];
          let _0x334036 = "Example: " + _0x42ccef + " ServiceID|Jumlah|Link";
          if (!_0x2943e5) {
            return _0x50a5a0(_0x334036);
          }
          if (!_0x2c981c) {
            return _0x50a5a0(_0x334036);
          }
          if (!_0x11f752) {
            return _0x50a5a0(_0x334036);
          }
          _0x4daff3(keyUrl, {
            method: "POST",
            key: keyApi,
            action: "add",
            service: _0x2943e5,
            link: _0x11f752,
            quantity: _0x2c981c
          }).then(_0x3994a0 => {
            if (_0x3994a0.success == false) {
              _0x50a5a0("" + _0x3994a0.error);
            } else {
              _0x4daff3(keyUrl, {
                method: "POST",
                key: keyApi,
                action: "status",
                order: "" + _0x3994a0.order
              }).then(_0x25dfc3 => {
                if (_0x25dfc3.success == false) {
                  _0x50a5a0("" + _0x25dfc3.error);
                } else {
                  _0x50a5a0("charge: " + _0x25dfc3.charge + "\nstart_count: " + _0x25dfc3.start_count + "\nstatus: " + _0x25dfc3.status + "\nremains: " + _0x25dfc3.remains + "\ncurrency: " + _0x25dfc3.currency);
                }
                console.log(_0x25dfc3);
              });
            }
            console.log(_0x3994a0);
          });
        }
        break;
      case "status":
        {
          if (!_0x2c380a) {
            return _0x50a5a0("Khusus Developer Bot!");
          }
          if (!q) {
            return _0x50a5a0("contoh: status idtransaksi(ORDER NUMBER)");
          }
          _0x4daff3(keyUrl, {
            method: "POST",
            key: keyApi,
            action: "status",
            order: "" + q
          }).then(_0x24ad84 => {
            if (_0x24ad84.success == false) {
              _0x50a5a0("" + _0x24ad84.error);
            } else {
              _0x50a5a0("charge: " + _0x24ad84.charge + "\nstart_count: " + _0x24ad84.start_count + "\nstatus: " + _0x24ad84.status + "\nremains: " + _0x24ad84.remains + "\ncurrency: " + _0x24ad84.currency);
            }
            console.log(_0x24ad84);
          });
        }
        break;
      case "s":
      case "stiker":
      case "sticker":
        {
          try {
            if (/image/.test(_0x231c50)) {
              let _0x1a3bae = await _0x43fba9.download();
              let _0x9a72c3 = await _0x2f598b.sendImageAsSticker(_0x56ef70.chat, _0x1a3bae, _0x56ef70, {
                packname: packname,
                author: author
              });
              await fs.unlinkSync(_0x9a72c3);
            } else if (/video/.test(_0x231c50)) {
              if ((_0x43fba9.msg || _0x43fba9).seconds > 11) {
                return _0x50a5a0("*Maximum 10 seconds!*");
              }
              let _0x4c3ee0 = await _0x43fba9.download();
              let _0x4fff74 = await _0x2f598b.sendVideoAsSticker(_0x56ef70.chat, _0x4c3ee0, _0x56ef70, {
                packname: packname,
                author: author
              });
              await fs.unlinkSync(_0x4fff74);
            } else {
              _0x50a5a0("*Kirim Video/foto dengan caption * " + _0x42ccef + "\nDuration *Video 1-9 Seconds*");
            }
          } catch (_0x5ccc1) {
            console.error(_0x5ccc1);
            _0x50a5a0("Terjadi kesalahan saat membuat stiker. Silakan coba lagi.");
          }
        }
        break;
      case "ytmp3":
      case "youtubemp3":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          if (!_0x2438f0) {
            throw "Example : " + (_0x2d41a8 + _0x42ccef) + " https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps";
          }
          await loading();
          downloadMp3(_0x2438f0);
        }
        break;
      case "ytmp4":
      case "youtubemp4":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          if (!_0x2438f0) {
            throw "Example : " + (_0x2d41a8 + _0x42ccef) + " https://youtube.com/watch?v=PtFMh6Tccag%27 360p";
          }
          let {
            ytv: _0x11e183
          } = require("./lib/y2mate");
          let _0x1aa76e = _0x3608a4[1] ? _0x3608a4[1] : "360p";
          let _0x256db4 = await _0x11e183(_0x2438f0, _0x1aa76e);
          if (_0x256db4.filesize >= 100000) {
            return _0x56ef70.reply("File Melebihi Batas " + util.format(_0x256db4));
          }
          _0x2f598b.sendMessage(_0x56ef70.chat, {
            video: {
              url: _0x256db4.dl_link
            },
            mimetype: "video/mp4",
            fileName: _0x256db4.title + ".mp4",
            caption: "⭔ Title : " + _0x256db4.title + "\n⭔ File Size : " + _0x256db4.filesizeF + "\n⭔ Url : " + isUrl(_0x2438f0) + "\n⭔ Ext : MP4\n⭔ Resolusi : " + (_0x3608a4[1] || "360p")
          }, {
            quoted: _0x56ef70
          });
        }
        break;
      case "getmusic":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          if (!_0x2438f0) {
            throw "Example : " + (_0x2d41a8 + _0x42ccef) + " 1";
          }
          if (!_0x56ef70.quoted) {
            return _0x56ef70.reply("Reply Pesan");
          }
          if (!_0x56ef70.quoted.isBaileys) {
            throw "Hanya Bisa Membalas Pesan Dari Bot";
          }
          let _0x42cf21 = _0x43fba9.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, "gi"));
          if (!_0x42cf21) {
            throw "Mungkin pesan yang anda reply tidak mengandung result ytsearch";
          }
          await loading();
          downloadMp3(_0x42cf21[_0x2438f0 - 1]);
        }
        break;
      case "getvideo":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          let {
            ytv: _0x50e734
          } = require("./lib/y2mate");
          if (!_0x2438f0) {
            throw "Example : " + (_0x2d41a8 + _0x42ccef) + " 1";
          }
          if (!_0x56ef70.quoted) {
            return _0x56ef70.reply("Reply Pesan");
          }
          if (!_0x56ef70.quoted.isBaileys) {
            throw "Hanya Bisa Membalas Pesan Dari Bot";
          }
          let _0x25e513 = _0x43fba9.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, "gi"));
          if (!_0x25e513) {
            throw "Mungkin pesan yang anda reply tidak mengandung result ytsearch";
          }
          let _0x961503 = _0x3608a4[1] ? _0x3608a4[1] : "360p";
          let _0x58e747 = await _0x50e734(_0x25e513[_0x2438f0 - 1], _0x961503);
          if (_0x58e747.filesize >= 100000) {
            return _0x56ef70.reply("File Melebihi Batas " + util.format(_0x58e747));
          }
          _0x2f598b.sendMessage(_0x56ef70.chat, {
            video: {
              url: _0x58e747.dl_link
            },
            mimetype: "video/mp4",
            fileName: _0x58e747.title + ".mp4",
            caption: "⭔ Title : " + _0x58e747.title + "\n⭔ File Size : " + _0x58e747.filesizeF + "\n⭔ Url : " + _0x25e513[_0x2438f0 - 1] + "\n⭔ Ext : MP3\n⭔ Resolusi : " + (_0x3608a4[1] || "360p")
          }, {
            quoted: _0x56ef70
          });
        }
        break;
      case "ytreels":
      case "youtubereels":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          if (!_0x2438f0) {
            return _0x56ef70.reply("Masukan Link Nya!!!");
          }
          await loading();
          downloadMp4(_0x2438f0);
        }
        break;
      case "tiktok":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          if (!_0x2438f0) {
            return _0x56ef70.reply("Example : " + (_0x2d41a8 + _0x42ccef) + " link");
          }
          if (!q.includes("tiktok")) {
            return _0x56ef70.reply("Link Invalid!!");
          }
          await loading();
          require("./lib/tiktok").Tiktok(q).then(_0x1b592e => {
            _0x2f598b.sendMessage(_0x56ef70.chat, {
              video: {
                url: _0x1b592e.nowm
              }
            }, {
              quoted: _0x56ef70
            });
          });
        }
        break;
      case "tiktokmp3":
      case "tiktokaudio":
        {
          if (!isCreator) {
            return _0x56ef70.reply("*khusus Premium*");
          }
          if (!_0x2438f0) {
            return _0x56ef70.reply("Example : " + (_0x2d41a8 + _0x42ccef) + " link");
          }
          if (!q.includes("tiktok")) {
            return _0x56ef70.reply("Link Invalid!!");
          }
          await loading();
          require("./lib/tiktok").Tiktok(q).then(_0x4ec8b9 => {
            _0x2f598b.sendMessage(_0x56ef70.chat, {
              audio: {
                url: _0x4ec8b9.audio
              },
              mimetype: "audio/mp4"
            }, {
              quoted: _0x56ef70
            });
          });
        }
        break;
      case "ig":
      case "igreels":
        if (_0x3608a4.length == 0) {
          return _0x50a5a0("Example: " + (_0x2d41a8 + _0x42ccef) + " https://www.instagram.com/tv/CXwPLSIFDW0/?igshid=NTc4MTIwNjQ2YQ==");
        }
        await loading();
        axios.get("https://api.lolhuman.xyz/api/instagram?apikey=" + apikey + "&url=" + _0x3608a4[0]).then(({
          data: _0x152c9a
        }) => {
          _0x2f598b.sendMessage(_0x1c3709, {
            video: {
              url: _0x152c9a.result
            },
            mimetype: "video/mp4",
            caption: "silahkan ketik tovn atau to audio untuk merubah nya menjadi audio / vn"
          });
        });
        break;
      case "addprem":
        if (!isCreator) {
          return;
        }
        if (!_0x3608a4[0]) {
          return _0x50a5a0("Penggunaan " + (_0x2d41a8 + _0x42ccef) + " nomor\nContoh " + (_0x2d41a8 + _0x42ccef) + " 6287856451890");
        }
        bnnd = _0x2438f0.split("|")[0].replace(/[^0-9]/g, "");
        let _0x145cf9 = await _0x2f598b.onWhatsApp(bnnd + "@s.whatsapp.net");
        if (_0x145cf9.length == 0) {
          return _0x50a5a0("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");
        }
        owner.push(bnnd);
        fs.writeFileSync("./premium.json", JSON.stringify(owner));
        _0x50a5a0("Nomor " + bnnd + " Menjadi Premium!!!");
        break;
      case "delprem":
        if (!isCreator) {
          return;
        }
        if (!_0x3608a4[0]) {
          return _0x50a5a0("Penggunaan " + (_0x2d41a8 + _0x42ccef) + " nomor\nContoh " + (_0x2d41a8 + _0x42ccef) + " 6283829814737");
        }
        yaki = _0x2438f0.split("|")[0].replace(/[^0-9]/g, "");
        unp = owner.indexOf(yaki);
        owner.splice(unp, 1);
        fs.writeFileSync("./premium.json", JSON.stringify(owner));
        _0x50a5a0("Nomor " + yaki + " Telah Di Hapus Dari Premium!!!");
        break;
      case "listprem":
        if (isBan) {
          return _0x50a5a0("*Lu Di Ban Owner*");
        }
        teksooo = "▢ *List Premium*\n\n\n";
        for (let _0xbbdf89 of owner) {
          teksooo += "- " + _0xbbdf89 + "\n";
        }
        teksooo += "\n*Total : " + owner.length + "*";
        _0x2f598b.sendMessage(_0x1c3709, {
          text: teksooo.trim()
        }, "extendedTextMessage", {
          quoted: _0x56ef70,
          contextInfo: {
            mentionedJid: owner
          }
        });
        break;
      default:
    }
  } catch (_0x368b4e) {
    console.log(_0x368b4e);
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.yellowBright("Update File Terbaru " + __filename));
  delete require.cache[file];
  require(file);
});